# -*- coding: utf-8 -*-
from flask import render_template, request,redirect
from flask import Blueprint, flash, Flask
from app.models.Form import formulario
from app.models.login import formLogin
from app.models.formserie import formSerie
from app.models.usuario import Usuario
from app.models.classes.serie import Serie

from flask_sqlalchemy import SQLAlchemy
#from app.models.serverDao import db
#from app.models.daoTemporada import TemporadaDAO
#from app.models.daoSerie import SerieDAO
#from app.models.serie import Serie
#from app.models.temporada import Temporada
#from app.models.dao import UsuarioDAO

from app import db


usuario = Blueprint('usuario', __name__, url_prefix='/user')

@usuario.route('/cadastro')
def printer():
    form = formulario()
    return render_template('printer/CadastroUsuario.html',form = form)


@usuario.route('/salvar',methods=['GET','POST'])
def salvar():
    form = formulario()
    if form.validate_on_submit():
        user = Usuario()
        user.email = form.email.data
        user.altura = form.altura.data
        user.idade = form.idade.data
        user.login = form.login.data
        user.nome = form.nome.data
        user.senha = form.senha.data
        db.session.add(user)
        db.session.commit()
        return "inserido com sucesso!"
    return render_template('printer/CadastroUsuario.html',form = form)

@usuario.route('/deletarUsuario')
def deletarUsuario():
    cod = request.args['cod']
    Usuario.query.filter_by(id=cod).delete()
    db.session.commit()
    return render_template('printer/login.html',form = form)

@usuario.route('/login')
def loginform():
    form = formLogin()
    return render_template('printer/login.html',form = form)

@usuario.route('/verificar',methods=['GET','POST'])
def verificar():
    form = formLogin()
    if form.validate_on_submit():
        resp = Usuario.query.filter_by(login=request.form['login'],senha= request.form['senha']).all()
        if resp == None:
            flash("Senha ou email incorretos")
            return render_template('printer/login.html',form = form)
        else:
            for row in resp:
                print(row['login'])
            return render_template('printer/login.html',form = form)
    return render_template('printer/login.html',form = form)

@usuario.route('/verificarSerie',methods=['GET','POST'])
def verificarSerie():
    form = formSerie()
    if form.validate_on_submit():
        dao = SerieDAO()
        temp = TemporadaDAO()
        serie = Serie(titulo=request.form['titulo'])
        dao.inserir(serie)
        return "inserido com sucesso!"
    return render_template('printer/cadastro.html',form = form)

@usuario.route('/listarSerie')
def listarSerie():
    lista = Usuario.query.all()
    return render_template('printer/listarSerie.html',lista = lista)

