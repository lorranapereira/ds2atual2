# -*- coding: utf-8 -*-
from flask import render_template, request,redirect
from flask import Blueprint, flash, Flask
from app.models.Form import formulario
from app.models.formserie import formSerie
from app.models.usuario import Usuario
from flask_sqlalchemy import SQLAlchemy
#from app.models.serverDao import db
#from app.models.daoTemporada import TemporadaDAO
#from app.models.daoSerie import SerieDAO
#from app.models.serie import Serie
#from app.models.temporada import Temporada
#from app.models.dao import UsuarioDAO

from app import db
from app.models.departamento import Departamento


control = Blueprint('control', __name__, url_prefix='/')
@control.route('/')
def start():
    db.create_all()
    return render_template('printer/index.html')