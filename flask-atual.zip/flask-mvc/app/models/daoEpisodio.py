from psycopg2 import connect
from app.models.serverDao import db
from app.models.episodio import Episodio

class EpisodioDAO(DAO):
    def __init__(self):
        super().__init__()    
    def inserir(self, episodio):
        try: 
            with connect(self._dados_con) as conn:
                cur = conn.cursor()
                cur.execute('insert into episodio(titulo,numero) values (%s,%s)',[episodio.titulo,episodio.numero])
                conn.commit()
                cur.close()
                return "Inserido com!"
        except BaseException as e:
            print ("Problema no inserir -- exception seguindo para ser tratada")
            raise e


        if usuario.persistido():
            self.alterar(usuario)
        else:
            self.inserir(usuario)