from flask_wtf import FlaskForm
from wtforms import SubmitField,StringField,DecimalField,RadioField,PasswordField,TextAreaField,IntegerField,HiddenField
from wtforms.validators import DataRequired,Optional, Length
from wtforms_components import EmailField
from flask_bootstrap import Bootstrap
from flask_babel import Babel
class formulario(FlaskForm):
    tipo = "cadastro"
    cod = HiddenField()
    nome = StringField('Nome',validators=[DataRequired()])
    altura = DecimalField('Altura',validators=[DataRequired()])
    senha = PasswordField('Senha',validators=[DataRequired()])
    idade = IntegerField('Idade',validators=[DataRequired()])
    login = StringField('Login',validators=[DataRequired()])
    email =  EmailField('Email',validators=[DataRequired()])
    enviar = SubmitField('Enviar')
