from psycopg2 import connect
from app.models.serverDao import db
from app.models.serie import Serie

class SerieDAO(DAO):
    def __init__(self):
        super().__init__()    
    def inserir(self, serie):
        from app.models.serverDao import DAO
        try: 
            with connect(self._dados_con) as conn:
                cur = conn.cursor()
                cur.execute('insert into serie(titulo) values (%s)',[serie.titulo])
                conn.commit()
                cur.close()
                return "Inserido com sucesso!"
        except BaseException as e:
            print ("Problema no inserir -- exception seguindo para ser tratada")
            raise e


        if serie.persistido():
            self.alterar(serie)
        else:
            self.inserir(serie)